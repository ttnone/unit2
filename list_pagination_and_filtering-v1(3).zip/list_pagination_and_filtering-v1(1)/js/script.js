/******************************************
Treehouse Techdegree:
FSJS project 2 - List Filter and Pagination
******************************************/
   //maybe do a show hide
// Study guide for this project - https://drive.google.com/file/d/1OD1diUsTMdpfMDv677TfL1xO2CEkykSz/view?usp=sharing
const wk=document.createElement("LINK");
//const num=0;
//const lit = document.querySelectorAll(" li");
//math.max 
//if(lit.length >  10){
	//const hm= document.implementation.createHTMLDocument("New Document");
	

//const yt= document.getElementsByTagName("div")[0];
//var rt=lit(5).keys();

//if(lit.length >  10){
document.implementation.createHTMLDocument("New Document");
//list of varibles	
const ser=document.createElement('input');
const lit = document.querySelectorAll('LI');
const yt= document.getElementsByTagName("div")[0];
const jay =[];
const nt=[];
//shouts it down
  for(var t=0;t<lit.length;t++){
    lit[t].style.display="none";
  }
/*for(var u =0;u<lit.lenth;u+=10){
 const ty= document.createElement("button").setAttribute("className","rt");
 yt.appendChild(ty);
}*/
//counts 
var arayray=[];
for(var t=1; t<lit.length;t+=10){
  arayray.push(t);
}
//counts in order
for(var tb =0;tb<arayray.length; tb++){
	nt.push(tb);
}
//creates buttons and stuff
nt.forEach(function(item){
  
  const yu =document.createElement("button");
 yu.className="gooy";
  // const po = dam(yu,gy);

  yu.innerHTML=item;
  yu.style.bottom="10px";
  
 yt.appendChild(yu);
 
});

/*const sera=document.createElement("button");
ser.type ='text';
ser.style.top ="9px";
ser.style.right="18px";
sera.innerText='search';
sera.style.backgroundColor='blue';
ser.style.position="absolute";
sera.style.top="9px";
sera.style.position='absolute';
yt.appendChild(sera);
yt.appendChild(ser);
yt.insertBefore(sera,ser);
sera.style.left='700px';
var info=ser.value;*/
//does a convert for readiblity cause of array method
const so = Array.prototype.slice.call( lit );
//the arrays that list
const hope=so.slice(0,9);
const nope =so.slice(10,21);
const dope =so.slice(22,32);
const sope=so.slice(33,43);
const tope=so.slice(44,55);
const jope=so.slice(56,67);
const cope=so.slice(68,so.length-1);
//needed function to display and not display


function looped(hope){
	for(var sd=0;sd<hope.length;sd++){
	 hope[sd].style.display="block";
	}
}
function poo(hope){
	for(var sd=0;sd<hope.length;sd++){
	 hope[sd].style.display="none";
	}
}
/*const mat=(/^[a-zA-Z]+/g);
const ma=mat.exec(so);
ser.addEventListener('click',(event)=>{
	for(var y=0;y<so.length;y++){
	if ( info == ma){
	ma[y].style.display='block'}		
	 else{
		yt.innerHTML='nope';
	}
}*/

});
//another conversion
const reh= document.getElementsByClassName('gooy');
// the buttons listed out
reh[0].addEventListener('click',(event) =>{
	poo(nope);
	poo(dope);
	poo(sope);
	poo(tope);
	poo(jope);
looped(hope);
	

});
reh[1].addEventListener('click',(event) =>{
	poo(hope);
	poo(dope);
	poo(tope);
	poo(sope);
	poo(jope);
looped(nope);

});
reh[2].addEventListener('click',(event) =>{
poo(nope);
poo(hope);
poo(tope);
poo(sope);
poo(jope);
looped(dope);


});
reh[3].addEventListener('click',(event) =>{
	poo(nope);
	poo(hope);
	poo(dope);
	poo(tope);
	poo(jope);
looped(sope);
});
reh[4].addEventListener('click',(event) =>{
	poo(hope);
	poo(nope);
	poo(dope);
	poo(sope);
	poo(jope);
looped(tope);
});

reh[5].addEventListener('click',(event) =>{
	poo(hope);
	poo(nope);
	poo(dope);
	poo(sope);
	poo(tope);
looped(jope);
});
reh[6].addEventListener('click',(event) =>{
	poo(hope);
	poo(nope);
	poo(dope);
	poo(sope);
	poo(tope);
looped(jope);
});

//yt.innerHTML=hope.textContent;





















/*for(var i in lit) {
	lit[i]
}
create a function*/

//while(lit.length < 10)

/*** 
   Add your global variables that store the DOM elements you will 
   need to reference and/or manipulate. 
   
   But be mindful of which variables should be global and which 
   should be locally scoped to one of the two main functions you're 
   going to create. A good general rule of thumb is if the variable 
   will only be used inside of a function, then it can be locally 
   scoped to that function.
***/




/*** 
   Create the `showPage` function to hide all of the items in the 
   list except for the ten you want to show.

   Pro Tips: 
     - Keep in mind that with a list of 54 students, the last page 
       will only display four.
     - Remember that the first student has an index of 0.
     - Remember that a function `parameter` goes in the parens when 
       you initially define the function, and it acts as a variable 
       or a placeholder to represent the actual function `argument` 
       that will be passed into the parens later when you call or 
       "invoke" the function 
***/




/*** 
   Create the `appendPageLinks function` to generate, append, and add 
   functionality to the pagination buttons.
***/





// Remember to delete the comments that came with this file, and replace them with your own code comments.